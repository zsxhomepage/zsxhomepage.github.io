function SCSS_LIPS()

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SCSS: Sheng Xin Zhang,Wing Shing Chan,Zi Kang Peng,Shao Yong Zheng,and Kit Sang Tang,
% "Selective-Candidate Framework with Similarity Selection Rule for Evolutionary Optimization," 
% arXiv preprint arXiv:1712.06338

% LIPS: B. Y. Qu, P. N. Suganthan, and S. Das, 
% �A distance-based locally informed particle swarm model for multimodal optimization,�  
% IEEE Trans. Evol. Comput., vol. 17, no. 3, pp. 387-402, Jun. 2013.

% % For this package, the source code of LIPS was obtained from Dr. P.N.Suganthan's homepage http://www.ntu.edu.sg/home/epnsugan/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    clc;
    clear all;
    format long;
    format compact;
    currentPath = cd;
    cauchyPath = sprintf('%s/cauchy', currentPath);
    addpath(genpath(cauchyPath));
    rand('seed', sum(100 * clock));
    val_2_reach = 10^(-8);
    fbis = [100:100:3000];
    num_particle = 40;
    dimension = 30;
    max_FES = 10000*dimension;
    M = 4;
    range=[-100,100];

    % acc=[2.05 2.05]; % acceleration coefficients
    weight=0.729843788;% weight
    % nsize=[2,5]; % neightborhood size

    range_min=range(1)*ones(num_particle,dimension); % position range
    range_max=range(2)*ones(num_particle,dimension);
    interval = range_max-range_min;
    v_max=interval*0.5; % velocity range
    v_min=-v_max;

 for func = 1:30
    SCSS_LIPS = [];
    func = func
  for irun = 1:3 
    pos = range_min+ interval.*rand(num_particle,dimension);    % Initial position
    vel = v_min+(v_max-v_min).*rand(num_particle,dimension); % Initial velocity   
    result = cec14_func(pos', func);
    fitcount = num_particle;
    [gbest_val,g_index]=min(result); % Initialize global best position
    gbest_pos=pos(g_index,:);
    pbest_pos=pos; % Initialize pbest position
    pbest_val=result;
    nsize=3;
    
while  fitcount<=max_FES
   [~,idxx] =  sort(pbest_val); rank = zeros(1,num_particle);
    for i = 1:num_particle
        rank(idxx(i)) = i;
    end	
    
    for i=1:num_particle
        Distance = zeros(M,1);
        U_ALL = cell(1,M);
        EU_dist=dist(pbest_pos(i,:),pbest_pos'); 
        EU_dist(i)=max(EU_dist);
        [min_dist,min_index]=sort(EU_dist);
        Xold = pos(i,:); Vold(i,:) = vel(i,:);
       for VN = 1:M
        fai=(4.1./nsize).*rand(nsize,dimension);
        lbest_pos=(sum(fai.*pbest_pos(min_index(1:nsize),:)))./sum(fai); 
        delta(i,:)=(sum(fai).*(lbest_pos-Xold));
        vel(i,:)=weight.*(Vold(i,:)+delta(i,:));
        vel(i,:)=((vel(i,:)<v_min(i,:)).*v_min(i,:))+((vel(i,:)>v_max(i,:)).*v_max(i,:))+(((vel(i,:)<v_max(i,:))&(vel(i,:)>v_min(i,:))).*vel(i,:));
        pos(i,:)=Xold+vel(i,:);
        pos(i,:)=((pos(i,:)>=range_min(i,:))&(pos(i,:)<=range_max(i,:))).*pos(i,:)+(pos(i,:)<range_min(i,:)).*(range_min(i,:)+0.25.*(range_max(i,:)-range_min(i,:)).*rand(1,dimension))+(pos(i,:)>range_max(i,:)).*(range_max(i,:)-0.25.*(range_max(i,:)-range_min(i,:)).*rand(1,dimension));
        U_ALL{VN} = pos(i,:);
        Distance(VN,1) = norm(U_ALL{VN}-pbest_pos(i,:));  
      
        end
          if rand > rank(i)/num_particle
             [~,Idx] = min([Distance]);
          else
             [~,Idx] = max([Distance]);
          end
          pos(i,:) = U_ALL{Idx};
    end 

        for i=1:num_particle  % Evaluate Fitness
            if (sum(pos(i,:)>range_max(i,:))+sum(pos(i,:)<range_min(i,:))==0)% check if new position is within range
                result(i) = cec14_func(pos(i,:)', func);
                fitcount=fitcount+1;
                if fitcount>=max_FES
                   break;
                end
            end
            if  result(i)<pbest_val(i) % update pbest value and position
                pbest_pos(i,:)=pos(i,:);   
                pbest_val(i)=result(i);
            end
            
            if  pbest_val(i)<gbest_val; % update gbest value and postion
                gbest_pos=pbest_pos(i,:); 
                gbest_val=pbest_val(i);
            end   
        end 

    if fitcount>=max_FES
       break;
    end 
end
      minfx = gbest_val-fbis(func);
      if minfx <= val_2_reach
          minfx = 0;
      end
       SCSS_LIPS = [SCSS_LIPS,minfx]
  end
 end 
end



