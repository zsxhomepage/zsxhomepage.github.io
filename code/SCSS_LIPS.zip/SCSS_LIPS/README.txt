%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SCSS: Sheng Xin Zhang,Wing Shing Chan,Zi Kang Peng,Shao Yong Zheng,and Kit Sang Tang,
% "Selective-Candidate Framework with Similarity Selection Rule for Evolutionary Optimization," 
% arXiv preprint arXiv:1712.06338

% LIPS: B. Y. Qu, P. N. Suganthan, and S. Das, 
% �A distance-based locally informed particle swarm model for multimodal optimization,�  
% IEEE Trans. Evol. Comput., vol. 17, no. 3, pp. 387-402, Jun. 2013.

% % For this package, the source code of LIPS was obtained from Dr. P.N.Suganthan's homepage http://www.ntu.edu.sg/home/epnsugan/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%