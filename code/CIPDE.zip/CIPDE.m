%**************************************************************************************************
%Reference:  Li Ming Zheng, Sheng Xin Zhang, Kit Sang Tang, Shao Yong Zheng, 
%            Differential evolution powered by collective information, Information Sciences. 399 (2017) 13�C29.
%**************************************************************************************************
function outcome=CIPDE()

    clc;
    clear all;
    format long;
    format compact;
    rand('seed', sum(100 * clock));
    problemSet = [1:28];
    foptimum = [-1400:100:-100,100:100:1400];
 
for problemIndex = 1:28 

    problem = problemSet(problemIndex) 
   
    % Define the dimension of the problem
    n = 50;
    totalTime = 1;
    popsize = 100;
    lu = [-100 * ones(1, n); 100 * ones(1, n)];

    % Record the best results
    outcome = []; 

    for time = 1: totalTime
        % Initialize the main population
        popold = repmat(lu(1, :), popsize, 1) + rand(popsize, n) .* (repmat(lu(2, :) - lu(1, :), popsize, 1));

        valParents = cec13_func(popold', problem)';
        c = 1/10;
        CRm = 0.5;
        Fm = 0.7;
        T = 90;
        FES = 0; goodCR=[];goodF=[];
        UN_UP = zeros(popsize,1);
        %%
        while FES < n * 10000 %& min(fit)>error_value(problem)

            pop = popold; % the old population becomes the current population

            if FES > 1 && ~isempty(goodCR) && sum(goodF) > 0 % If goodF and goodCR are empty, pause the update
                CRm = (1 - c) * CRm + c * mean(goodCR);
                Fm = (1 - c) * Fm + c * sum(goodF .^ 2) / sum(goodF); % Lehmer mean
            end

            % Generate CR according to a normal distribution with mean CRm, and std 0.1
            % Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
            [F, CR] = randFCR(popsize, CRm, 0.1, Fm, 0.1);

            r0 = [1 : popsize];
            [r1, r2] = gnR1R2(popsize, r0);
            rank_i=zeros(1,popsize);
            [valBest, indBest] = sort(valParents, 'ascend');
            rank_i(indBest)=1:popsize;    
            K = ceil(rand(1,popsize).*rank_i);
            CI_pop = pop; X = pop; popx = pop(indBest,:);
            K_S=[]; CI_S=[];
           for i = 1:popsize
               if isempty(find(K(1,i)==K_S))
                    W = fliplr((1:K(1,i))/sum(1:K(1,i)));
                   for k = 1:K(1,i)
                        X(k,:) = popx(k,:).*W(1,k);
                   end
                    CI_pop(i,:) = sum(X(1:K(1,i),:),1); 
                    K_S=[K_S,K(1,i)];
                    CI_S=[CI_S;CI_pop(i,:)];
               else
                   IDX=find(K(1,i)==K_S);
                   CI_pop(i,:)=CI_S(IDX,:);
               end
           end

            vi = pop + F(:, ones(1, n)) .* (CI_pop - pop + pop(r1, :) - pop(r2, :));

            % == == == == = Crossover == == == == =
            mask = rand(popsize, n) > CR(:, ones(1, n)); % mask is used to indicate which elements of ui comes from the parent
            rows = (1 : popsize)'; cols = floor(rand(popsize, 1) * n)+1; % choose one position where the element of ui doesn't come from the parent
            jrand = sub2ind([popsize n], rows, cols); mask(jrand) = false;
            ui = vi; popX = pop; popX(UN_UP > T,:) = CI_pop(UN_UP > T,:) ;
            ui(mask) = popX(mask); 
            ui = boundConstraint(ui, pop, lu); 

            valOffspring = cec13_func(ui', problem)';
            FES = FES + popsize;

            % == == == == == == == == == == == == == == == Selection == == == == == == == == == == == == ==
            % I == 1: the parent is better; I == 2: the offspring is better
            [valParents, I] = min([valParents, valOffspring], [], 2);
            popold = pop;

            popold(I == 2, :) = ui(I == 2, :);

            goodCR = CR(I == 2);
            goodF = F(I == 2);
            UN_UP(I == 1) = UN_UP(I == 1) + 1;
            UN_UP(I == 2) = 0;

        end
        fmin = min(valParents)-foptimum(problemIndex);
        outcome = [outcome fmin];
        fprintf('CIPDE_%d th run, best-so-far error value = %1.8e\n', time , fmin) 
    end

   fprintf('\n')
   fprintf('CIPDE__mean error value = %1.8e, std = %1.8e\n', mean(outcome), std(outcome))

end


