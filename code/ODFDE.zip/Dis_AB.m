function Distance = Dis_AB(A,B,NP)
    Distance = zeros(1,NP);
       for  i = 1:NP
           Distance(i) = norm(A(i,:)-B(i,:));
       end
end