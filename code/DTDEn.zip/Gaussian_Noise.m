function f_GN=Gaussian_Noise(f,noise_strength)
    f_GN=f.*exp(noise_strength*normrnd(zeros(size(f,1),1),1));
end