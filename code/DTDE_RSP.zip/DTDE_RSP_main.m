
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Reference 
% Implementation of the DTDE-RSP algorithm for noiseless optimization in 
% Sheng Xin Zhang, Yi Nan Wen, Yu Hong Liu, Li Ming Zheng, and Shao Yong Zheng, 
% Differential evolution with domain transform, IEEE Transactions on Evolutionary Computation, 
% vol. 27, no. 5, 1440−1455, Oct 2023.
%  Email: shengxinzhang@gmail.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function outcome=DTDE_RSP_main()
    warning off;
    rand('seed', sum(100 * clock));
    totaltime = 51;
    problem_size = 30;
    Thes = 0.1;
    max_nfes = 10000 * problem_size;

for func = [1,3:30]
    
   val_2_reach = 10^(-8);
   lu = [-100 * ones(1, problem_size); 100 * ones(1, problem_size)];  
   foptimum = [100:100:3000];
   optimum = foptimum(func);

  %% Record the best results
  outcome = []; 

  fprintf('\n-------------------------------------------------------\n')
  fprintf('Function = %d, Dimension size = %d\n', func, problem_size) 

 parfor run_id = 1 : totaltime
%   for run_id = 1 : 1
    p_best_rate = 0.11;
    arc_rate = 1;  
    memory_size = 5;
    pop_size = round(75 * problem_size^(2/3));
    max_pop_size = pop_size;
    min_pop_size = 4.0;

    %% Initialize the main population
    popold = repmat(lu(1, :), pop_size, 1) + rand(pop_size, problem_size) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
    pop = popold; % the old population becomes the current population

    fitness = cec17_func(pop',func)'- foptimum(func);
    nfes = 0;
    bsf_fit_var = 1e+30;
    bsf_solution = zeros(1, problem_size);

    %%%%%%%%%%%%%%%%%%%%%%%% for out
    for i = 1 : pop_size
      nfes = nfes + 1;
      if fitness(i) < bsf_fit_var
	bsf_fit_var = fitness(i);
	bsf_solution = pop(i, :);
      end

    if nfes > max_nfes; break; end
    end
    %%%%%%%%%%%%%%%%%%%%%%%% for out

    memory_sf = 0.3 .* ones(memory_size, 1);
    memory_cr = 0.8 .* ones(memory_size, 1);
    memory_pos = 1;

    archive.NP = arc_rate * pop_size; % the maximum size of the archive
    archive.pop = zeros(0, problem_size); % the solutions stored in te archive
    archive.funvalues = zeros(0, 1); % the function value of the archived solutions
    gen = 0;
    g_p_best_rate = 0.25;
    p_best_rate = g_p_best_rate;
    IMP_S = 0; IMP_I = 0; CT = 0; DT_Trig = 0;
    %% main loop
    while nfes < max_nfes
      gen = gen + 1;
      pop = popold; % the old population becomes the current population
      [temp_fit, sorted_index] = sort(fitness, 'ascend');
      ranki = zeros(pop_size,1);
      ranki(sorted_index) = 1 : pop_size;
      k = 3;
      Rank = k.*(pop_size - ranki) + 1;
      Pr = Rank./sum(Rank);
      sf = zeros(pop_size,1);
      cr = zeros(pop_size,1);
      
    for VN = 1 : 2
       for i = 1:pop_size
        rmz = ceil(rand * memory_size);
        if rmz == memory_size
            mu_sf = 0.9; mu_cr = 0.9;
        else
            mu_sf = memory_sf(rmz);
            mu_cr = memory_cr(rmz);
        end
        if mu_cr < 0
            cr(i) = 0;
        else
            cr(i) = mu_cr + 0.1 * sqrt(-2 * log(rand)) * sin(2 * pi * rand); 
            if cr(i) > 1
                cr(i) = 1;
            elseif cr(i) < 0
                cr(i) = 0;
            end
        end
        if nfes < 0.25 * max_nfes && cr(i) < 0.7
            cr(i) = 0.7;
        end
        if nfes < 0.5 * max_nfes && cr(i) < 0.6
            cr(i) = 0.6;
        end
         if nfes < 0.6 * max_nfes && sf(i) > 0.7
            sf(i) = 0.7;
         end
        
        sf(i) = mu_sf + 0.1 * tan(pi * (rand - 0.5)); 
        while sf(i) <= 0
            sf(i) = mu_sf + 0.1 * tan(pi * (rand - 0.5));  
        end
        
        if sf(i) > 1
            sf(i) = 1;
        end
       end
       
        if nfes < 0.2 * max_nfes
            jsf = sf * 0.7;
        elseif nfes < 0.4 * max_nfes
            jsf = sf * 0.8;
        else
            jsf = sf * 1.2;
        end

      if DT_Trig==1
         jsf = 0.5 * ones(pop_size,1);
         sf = 0.5 * ones(pop_size,1); 
         cr = 0.5 * ones(pop_size,1);     
      end
      
      r0 = [1 : pop_size]; r1 = r0; r2 = r0;
      popAll = [pop; archive.pop];
      for m = 1 : pop_size
         r1(m) = randsrc(1,1,[1:pop_size;Pr']);
        while r1(m) == m
            r1(m) = randsrc(1,1,[1:pop_size;Pr']);
        end
        r2(m) = ceil(rand * size(popAll, 1));
        while r2(m) == m || r2(m) == r1(m)
            r2(m) = ceil(rand * size(popAll, 1));
        end
      end
      
      pNP = max(round(p_best_rate * pop_size), 2); %% choose at least two best solutions
      randindex = ceil(rand(1, pop_size) .* pNP); %% select from [1, 2, 3, ..., pNP]
      randindex = max(1, randindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
      pbest = pop(sorted_index(randindex), :); %% randomly choose one of the top 100p% solutions

      vi = pop + jsf(:, ones(1, problem_size)) .* (pbest - pop) + sf(:, ones(1, problem_size)).* (pop(r1, :) - popAll(r2, :));
      vi = boundConstraint(vi, pop, lu);
      
      mask = rand(pop_size, problem_size) > cr(:, ones(1, problem_size)); % mask is used to indicate which elements of ui comes from the parent
      rows = (1 : pop_size)'; cols = floor(rand(pop_size, 1) * problem_size)+1; % choose one position where the element of ui doesn't come from the parent
      jrand = sub2ind([pop_size problem_size], rows, cols); mask(jrand) = false;
      ui = vi; ui(mask) = pop(mask);
   
      if VN == 1
          u1 = ui;
         Distance1 = zeros(1,pop_size);
          for i = 1 : pop_size
              Distance1(i) = norm(u1(i,:) - pop(i,:));
          end
          sf1 = sf;
          cr1 = cr;
      elseif VN == 2
          u2 = ui;
          Distance2 = zeros(1,pop_size);
          for i = 1 : pop_size
              Distance2(i) = norm(u2(i,:) - pop(i,:));
          end 
          sf2 = sf;
          cr2 = cr;
      end
     end
    
   for i = 1 : pop_size
      if rand > ranki(i)/pop_size  
         [~,Idx] = min([Distance1(i),Distance2(i)]);
      else
         [~,Idx] = max([Distance1(i),Distance2(i)]);
      end
      if Idx == 1
          ui(i,:) = u1(i,:); sf(i) = sf1(i); cr(i) = cr1(i);
      else
          ui(i,:) = u2(i,:); sf(i) = sf2(i); cr(i) = cr2(i);
      end
    end
      
     if DT_Trig == 0
          CT = CT + 1;
          if CT == 10
             CT = 0; 
             if IMP_S > IMP_I
                 DT_Trig = 1;
             end
             IMP_S = 0;  IMP_I = 0; 
          end 
     end
     
    if DT_Trig == 1     
        fo = cec17_func(ui',func)' - optimum;
        u_val_f = fo;
        f_trans = DTEO([pop;ui],[fitness;fo],Thes); 
        fitness = f_trans(1 : pop_size);  
        children_fitness = f_trans(pop_size + 1 : 2 * pop_size); 
    else
       children_fitness = cec17_func(ui',func)' - optimum;
       u_val_f = children_fitness;
    end

      %%%%%%%%%%%%%%%%%%%%%%%% for out
      for i = 1 : pop_size
	nfes = nfes + 1;
	if u_val_f(i) < bsf_fit_var
	  bsf_fit_var = u_val_f(i);
	  bsf_solution = ui(i, :);
	end

	%%	if nfes > max_nfes; exit(1); end
	if nfes > max_nfes; break; end
      end
      %%%%%%%%%%%%%%%%%%%%%%%% for out

      dif = abs(fitness - children_fitness);

      %% I == 1: the parent is better; I == 2: the offspring is better
      I = (fitness > children_fitness);
      goodCR = cr(I == 1);  
      goodF = sf(I == 1);
      dif_val = dif(I == 1);

      if DT_Trig == 0
          SP = ranki <= ceil(pop_size/2);
          IP = ranki > ceil(pop_size/2);
          dif_val_S = dif((I == 1) & (SP == 1));
          dif_val_I = dif((I == 1) & (IP == 1));
          IMP_S = IMP_S + sum(dif_val_S);
          IMP_I = IMP_I + sum(dif_val_I);
      end
      
      archive = updateArchive(archive, popold(I == 1, :), fitness(I == 1));

      [fitness, I] = min([fitness, children_fitness], [], 2);     
      popold = pop;
      popold(I == 2, :) = ui(I == 2, :);

      num_success_params = numel(goodCR);
      if num_success_params > 0 
    old_sf = memory_sf(memory_pos);
    old_cr = memory_cr(memory_pos);
	sum_dif = sum(dif_val);
	dif_val = dif_val / sum_dif;

	%% for updating the memory of scaling factor 
	memory_sf(memory_pos) = (dif_val' * (goodF .^ 2)) / (dif_val' * goodF);

	%% for updating the memory of crossover rate
	if max(goodCR) == 0 || memory_cr(memory_pos)  == -1
	  memory_cr(memory_pos)  = -1;
	else
	  memory_cr(memory_pos) = (dif_val' * (goodCR .^ 2)) / (dif_val' * goodCR);
	end
    memory_sf(memory_pos) = (memory_sf(memory_pos) + old_sf) / 2;
    memory_cr(memory_pos) = (memory_cr(memory_pos) + old_cr) / 2;
	memory_pos = memory_pos + 1;
	if memory_pos > memory_size;  memory_pos = 1; end
      end

      %% for resizing the population size
      plan_pop_size = round((((min_pop_size - max_pop_size) / max_nfes) * nfes) + max_pop_size);

      if pop_size > plan_pop_size
	reduction_ind_num = pop_size - plan_pop_size;
	if pop_size - reduction_ind_num <  min_pop_size; reduction_ind_num = pop_size - min_pop_size;end

	pop_size = pop_size - reduction_ind_num;
	for r = 1 : reduction_ind_num
	  [valBest indBest] = sort(fitness, 'ascend');
	  worst_ind = indBest(end);
	  popold(worst_ind,:) = [];
	  pop(worst_ind,:) = [];
	  fitness(worst_ind,:) = [];
    end
    p_best_rate = 0.085 + 0.085 * nfes / max_nfes;  
	archive.NP = round(arc_rate * pop_size); 

	if size(archive.pop, 1) > archive.NP 
	  rndpos = randperm(size(archive.pop, 1));
	  rndpos = rndpos(1 : archive.NP);
	  archive.pop = archive.pop(rndpos, :);
	end
      end
    end

    bsf_error_val = bsf_fit_var;
    if bsf_error_val < val_2_reach
        bsf_error_val = 0;
     end
    fprintf('DTDE_RSP_%d th run, best-so-far error value = %1.8e\n', run_id , bsf_error_val)
    outcome = [outcome bsf_error_val];    
  end %% end 1 run
  fprintf('\n')
  fprintf('DTDE_RSP_mean error value = %1.8e, std = %1.8e, min = %1.8e\n', mean(outcome), std(outcome), min(outcome))
  
%  filename='DTDE_RSP_cec17.xlsx';
%  if problem_size == 30
%   rowid = sprintf('A%d', func);
%   xlswrite(filename,sort(outcome),'D30',rowid); 
%   xlswrite(filename,[mean(outcome),std(outcome)],'D30mean&std',rowid); 
%   elseif problem_size == 50
%   rowid = sprintf('A%d', func);
%   xlswrite(filename,sort(outcome),'D50',rowid); 
%   xlswrite(filename,[mean(outcome),std(outcome)],'D50mean&std',rowid);
%    elseif problem_size == 100
%   rowid = sprintf('A%d', func);
%   xlswrite(filename,sort(outcome),'D100',rowid); 
%   xlswrite(filename,[mean(outcome),std(outcome)],'D100mean&std',rowid);
%  end
  
end %% end 1 function run
end
