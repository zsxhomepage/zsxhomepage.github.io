%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SCSS: Sheng Xin Zhang,Wing Shing Chan,Zi Kang Peng,Shao Yong Zheng,and Kit Sang Tang,
%"Selective-Candidate Framework with Similarity Selection Rule for Evolutionary Optimization," Preprint arXiv:1712.06338

%CMA-ES: N. Hansen and A. Ostermeier, 
%�Completely derandomized self-adaptation in evolution strategies,� Evol. Comput., vol. 9, no. 2, pp.159�195, 2001.

% For this package, the source code of CMA-ES was obtained from Prof. Q. Zhang�s homepage:http://dces.essex.ac.uk/staff/qzhang/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%