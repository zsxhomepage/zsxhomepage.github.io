function SCSS_CMAES()

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SCSS: Sheng Xin Zhang,Wing Shing Chan,Zi Kang Peng,Shao Yong Zheng,and Kit Sang Tang,
%"Selective-Candidate Framework with Similarity Selection Rule for Evolutionary Optimization," Preprint arXiv:1712.06338

%CMA-ES: N. Hansen and A. Ostermeier, 
%�Completely derandomized self-adaptation in evolution strategies,� Evol. Comput., vol. 9, no. 2, pp.159�195, 2001.

% For this package, the source code of CMA-ES was obtained from Prof. Q. Zhang�s homepage:http://dces.essex.ac.uk/staff/qzhang/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    clc;
    clear all;
    format long;
    format compact;
    rand('seed', sum(100 * clock));
    val_2_reach = 10^(-8);
    fbis = [100:100:3000];
    n = 30;    
    lu = ones(2,n).*(-100);
    lu(2,:) = ones(1,n).*100;  
 for func = 1:30
    SCSS_CMAES = [];
    func = func
  for irun = 1:3    
        N = n;
        maxeval = 10000*N;  % stop criteria
        xmeanw = (lu(1, :) + rand(1, N) .* (lu(2, :) - lu(1, :)))'; % object parameter start point
        sigma = 0.25; minsigma = 1e-15; maxsigma = max(lu(2, :)-lu(1, :)) / sqrt(n); % initial step size, minimal step size
        flginiphase = 1; % Initial phase

        % Parameter setting: selection,
        lambda = 4 + floor(3 * log(N)); mu = floor(lambda/2);

        arweights = log((lambda + 1)/2) - log(1:mu)'; % muXone array for weighted recomb.
        % lambda = 10; mu = 2; arweights = ones(mu, 1); % uncomment for (2_I, 10)-ES
        % parameter setting: adaptation
        cc = 4/(N + 4); ccov = 2/(N + 2^0.5)^2;
        cs = 4/(N + 4); damp = (1 - min(0.7, N * lambda/maxeval)) / cs + 1;

        % Initialize dynamic strategy parameters and constants
        B = eye(N); D = eye(N); BD = B * D; C = BD * transpose(BD);
        pc = zeros(N, 1); ps = zeros(N, 1);
        cw = sum(arweights) / norm(arweights); chiN = N^0.5 * (1 - 1/(4 * N) + 1/(21 * N^2));

        % Generation loop
        %     disp(['  (' num2str(mu) ', ' num2str(lambda) ')-CMA-ES (w = [' num2str(arweights', '%5.2f') '])' ]);
        

        % Boundary
        lb = (ones(lambda, 1) * lu(1, :))';
        ub = (ones(lambda, 1) * lu(2, :))';
        arfitness = 1e10;
        
        M = 5;
        Distance = zeros(M,lambda);
        arx_ALL = cell(1,M);
        arz_ALL = cell(1,M);
        counteval = 0; flgstop = 0; 
    while true
            % Set stop flag
            if counteval + lambda > maxeval || (min(arfitness)-fbis(func)) <= val_2_reach
                flgstop = 1;
            end
            if flgstop
                break;
            end
         for VN = 1:M
            % Generate and evaluate lambda offspring
            arz = randn(N, lambda);
            arx = xmeanw * ones(1, lambda) + sigma * (BD * arz);
            x_ = xmeanw * ones(1, lambda);
            I = find(arx > ub);
            arx(I) = 2 * ub(I) - arx(I);
            aa = find(arx(I) < lb(I));
            arx(I(aa)) = lb(I(aa));
            I = find(arx < lb);
            arx(I) = 2 * lb(I) - arx(I);
            aa = find(arx(I) > ub(I));
            arx(I(aa)) = ub(I(aa));
            if counteval > 0
                arx_ALL{VN} = arx;
                arz_ALL{VN} = arz;
                Distance(VN,:) = Dis_AB(arx_ALL{VN}',oldpop',lambda);
            end
         end

            if counteval > 0
                for i = 1 : lambda
                     [~,Idx] = max([Distance(:,i)]);
                      arx_S = arx_ALL{Idx};
                      arz_S = arz_ALL{Idx};
                      arx(:,i) = arx_S(:,i);
                      arz(:,i) = arz_S(:,i);
                end
            end           

            arfitness = zeros(lambda,1);
           	for i = 1 : lambda
                arfitness(i) = cec14_func(arx(:,i), func); 
            end
            counteval = counteval + lambda;
            % Sort by fitness and compute weighted mean in xmeanw
            [arfitness, arindex] = sort(arfitness); % minimization
            xold = xmeanw; % for speed up of Eq. (14)
            oldpop = arx;
            xmeanw = arx(:, arindex(1:mu)) * arweights/sum(arweights);
          
            zmeanw = arz(:, arindex(1:mu)) * arweights/sum(arweights);

            % Adapt covariance matrix
            pc = (1-cc) * pc + (sqrt(cc * (2-cc)) * cw/sigma) * (xmeanw-xold); % Eq. (14)
            if ~flginiphase % do not adapt in the initial phase
                C = (1-ccov) * C + ccov * pc * transpose(pc);           % Eq. (15)
            end
            % adapt sigma
            ps = (1-cs) * ps + (sqrt(cs * (2-cs)) * cw) * (B * zmeanw);      % Eq. (16)
            sigma = sigma * exp((norm(ps)-chiN)/chiN/damp);        % Eq. (17)

            % Update B and D from C
            if mod(counteval/lambda, 1/ccov/N/5) < 1
                C = triu(C) + transpose(triu(C, 1)); % enforce symmetry
                [B, D] = eig(C);
                % limit condition of C to 1e14 + 1
                if max(diag(D)) > 1e14 * min(diag(D))
                    tmp = max(diag(D))/1e14 - min(diag(D));
                    C = C + tmp * eye(N); D = D + tmp * eye(N);
                end
                D = diag(sqrt(diag(D))); % D contains standard deviations now
                BD = B * D; % for speed up only
            end % if mod

            % Adjust minimal step size
            if sigma * min(diag(D)) < minsigma ...
                    | arfitness(1) == arfitness(min(mu + 1, lambda)) ...
                    | xmeanw == xmeanw ...
                    + 0.2 * sigma * BD(:, 1 + floor(mod(counteval/lambda, N)))
                sigma = 1.4 * sigma;

                % flgstop = 1;
            end
            if sigma > maxsigma
                sigma = maxsigma;
            end

            % Test for end of initial phase
            if flginiphase & counteval/lambda > 2/cs
                if (norm(ps)-chiN)/chiN < 0.05 % step size is not much too small
                    flginiphase = 0;
                end
            end

    end
      minfx = min(arfitness)-fbis(func);
      if minfx <= val_2_reach
          minfx = 0;
      end
       SCSS_CMAES = [SCSS_CMAES,minfx]
  end
  
 end
end



