    clc;
    clear all;
    format long;
    format compact;
    Totaltime = 51;
    for D = [50]
       sig_vs_=[];sig_vs2_=[];
       Label_=sprintf('D%d',D);
       for func = [1:28]
           func=func
           [DATA1]=L_SHADE(func,Totaltime,D);
           [DATA2]=SCSS_L_SHADE(func,Totaltime,D);
           [DATA3]=EaDE(func,Totaltime,D);
            [w,p_i] = ranksumtest(DATA1', DATA2');
            sig_vs_=[sig_vs_,w] 
            [w,p_i] = ranksumtest(DATA1', DATA3');
            sig_vs2_=[sig_vs2_,w] 
       end
        w = sum(sum(sig_vs_'=='+'));
        t = sum(sum(sig_vs_'=='='));
        l = sum(sum(sig_vs_'=='-'));
        WXT = [w,t,l]
        w = sum(sum(sig_vs2_'=='+'));
        t = sum(sum(sig_vs2_'=='='));
        l = sum(sum(sig_vs2_'=='-'));
        WXT2 = [w,t,l]
    end
