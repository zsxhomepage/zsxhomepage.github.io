%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SCSS: Sheng Xin Zhang,Wing Shing Chan,Zi Kang Peng,Shao Yong Zheng,and Kit Sang Tang,
% "Selective-Candidate Framework with Similarity Selection Rule for Evolutionary Optimization," 
% arXiv preprint arXiv:1712.06338

% L-SHADE: R. Tanabe and A. S. Fukunaga, 
% "Improving the search performance of SHADE using linear population size reduction," 
% in Proc. IEEE Congr. Evol. Comput., Beijing, China, Jul. 2014, pp. 1658�1665.

% For this package, the source code of L-SHADE was downloaded from Dr. Tanabe's Homepage: https://ryojitanabe.github.io/publication
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 